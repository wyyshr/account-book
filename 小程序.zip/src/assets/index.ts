export {default as type_1} from './img/type_1.png';
export {default as type_2} from './img/type_2.png';
export {default as type_3} from './img/type_3.png';
export {default as type_4} from './img/type_4.png';
export {default as type_5} from './img/type_5.png';
export {default as type_6} from './img/type_6.png';
export {default as type_7} from './img/type_7.png';
export {default as type_8} from './img/type_8.png';

export {default as type_1_1} from './img/type_1_1.png';
export {default as type_1_2} from './img/type_1_2.png';
export {default as type_1_3} from './img/type_1_3.png';
export {default as type_1_4} from './img/type_1_4.png';
export {default as type_1_5} from './img/type_1_5.png';
export {default as type_1_6} from './img/type_1_6.png';
export {default as type_1_7} from './img/type_1_7.png';
export {default as type_1_8} from './img/type_1_8.png';