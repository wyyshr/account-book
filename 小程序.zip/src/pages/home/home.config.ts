export default {
  navigationBarTitleText: '记一笔'
}
