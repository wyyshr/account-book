export default {
  navigationBarTitleText: '记账'
}
