export default {
  navigationBarTitleText: '资产'
}
