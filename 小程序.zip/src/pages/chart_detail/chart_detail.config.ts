export default {
  navigationBarTitleText: '我的报表'
}
